// alert('test - JavaScript!');
// $(document).ready(function() {
//     console.log("ready!");
//     alert('test - JQuery');
// });