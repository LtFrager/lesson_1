// alert('test - JavaScript!');
// $(document).ready(function() {

var b = 5
console.log('b = ' + b)

c = (+'1' + +'2')
var b = c
console.log('b = c , c= 1 + 2 =' + c)


var a = ('Qwerty' + ' ' + 'Azerty')
console.log(a)

var i1, i2, i3
i1 = '2'
i2 = '4'
i3 = (+i1 + +i2)
console.log(i1 + "+" + i2 + "=" + i3)
    // });


// 1) Создать переменную b присвоить ей число 5, b присвоить с
// 2) бинарным плюсом с плюсовать два слова.Вывести через консоль
// 3) приплюсовать два слова унарными плюсами